﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSorteio_Click(object sender, EventArgs e)
        {
            int n1, n2;

            if (!int.TryParse(txtN1.Text, out n1) || !int.TryParse(txtN2.Text, out n2))
            {
                MessageBox.Show("Números inválidos!");
            }
            else
            {
                if ((n1 <= 0) || (n2 <= 0) || (n1 > n2))
                {
                    MessageBox.Show("Número 2 deve ser maior que número 1");
                }
                else
                {
                    Random objRandom = new Random();
                    int aleatorio = objRandom.Next(n1, n2);
                    MessageBox.Show("Número aleatório é: " +aleatorio);

                }
            }
        }
    }
}
