﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnComp_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPlvr1.Text, txtPlvr2.Text,true) == 0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("São diferentes");
            }
        }

        private void BtnInser2_Click(object sender, EventArgs e)
        {
            int metade = txtPlvr2.Text.Length / 2;

            txtPlvr2.Text = txtPlvr2.Text.Substring(0, metade) + txtPlvr1.Text + txtPlvr2.Text.Substring(metade, txtPlvr2.Text.Length - metade);
        }

        private void BtnInser1_Click(object sender, EventArgs e)
        {
            int metade = txtPlvr1.Text.Length / 2;
            txtPlvr2.Text = txtPlvr1.Text.Insert(metade, "**");
        }
    }
}
