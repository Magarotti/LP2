﻿namespace PMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPlvr1 = new System.Windows.Forms.Label();
            this.lblPlvr2 = new System.Windows.Forms.Label();
            this.btnComp = new System.Windows.Forms.Button();
            this.txtPlvr1 = new System.Windows.Forms.TextBox();
            this.txtPlvr2 = new System.Windows.Forms.TextBox();
            this.btnInser2 = new System.Windows.Forms.Button();
            this.btnInser1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPlvr1
            // 
            this.lblPlvr1.AutoSize = true;
            this.lblPlvr1.Location = new System.Drawing.Point(28, 25);
            this.lblPlvr1.Name = "lblPlvr1";
            this.lblPlvr1.Size = new System.Drawing.Size(52, 13);
            this.lblPlvr1.TabIndex = 0;
            this.lblPlvr1.Text = "Palavra 1";
            // 
            // lblPlvr2
            // 
            this.lblPlvr2.AutoSize = true;
            this.lblPlvr2.Location = new System.Drawing.Point(28, 98);
            this.lblPlvr2.Name = "lblPlvr2";
            this.lblPlvr2.Size = new System.Drawing.Size(52, 13);
            this.lblPlvr2.TabIndex = 1;
            this.lblPlvr2.Text = "Palavra 2";
            // 
            // btnComp
            // 
            this.btnComp.Location = new System.Drawing.Point(47, 200);
            this.btnComp.Name = "btnComp";
            this.btnComp.Size = new System.Drawing.Size(75, 55);
            this.btnComp.TabIndex = 2;
            this.btnComp.Text = "Comparar iguais";
            this.btnComp.UseVisualStyleBackColor = true;
            this.btnComp.Click += new System.EventHandler(this.BtnComp_Click);
            // 
            // txtPlvr1
            // 
            this.txtPlvr1.Location = new System.Drawing.Point(103, 22);
            this.txtPlvr1.Name = "txtPlvr1";
            this.txtPlvr1.Size = new System.Drawing.Size(321, 20);
            this.txtPlvr1.TabIndex = 3;
            // 
            // txtPlvr2
            // 
            this.txtPlvr2.Location = new System.Drawing.Point(103, 95);
            this.txtPlvr2.Name = "txtPlvr2";
            this.txtPlvr2.Size = new System.Drawing.Size(321, 20);
            this.txtPlvr2.TabIndex = 4;
            // 
            // btnInser2
            // 
            this.btnInser2.Location = new System.Drawing.Point(197, 200);
            this.btnInser2.Name = "btnInser2";
            this.btnInser2.Size = new System.Drawing.Size(75, 55);
            this.btnInser2.TabIndex = 5;
            this.btnInser2.Text = "Insere 1° meio 2°";
            this.btnInser2.UseVisualStyleBackColor = true;
            this.btnInser2.Click += new System.EventHandler(this.BtnInser2_Click);
            // 
            // btnInser1
            // 
            this.btnInser1.Location = new System.Drawing.Point(349, 200);
            this.btnInser1.Name = "btnInser1";
            this.btnInser1.Size = new System.Drawing.Size(75, 55);
            this.btnInser1.TabIndex = 6;
            this.btnInser1.Text = "Inserir asteriscos meio 1°";
            this.btnInser1.UseVisualStyleBackColor = true;
            this.btnInser1.Click += new System.EventHandler(this.BtnInser1_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 293);
            this.Controls.Add(this.btnInser1);
            this.Controls.Add(this.btnInser2);
            this.Controls.Add(this.txtPlvr2);
            this.Controls.Add(this.txtPlvr1);
            this.Controls.Add(this.btnComp);
            this.Controls.Add(this.lblPlvr2);
            this.Controls.Add(this.lblPlvr1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPlvr1;
        private System.Windows.Forms.Label lblPlvr2;
        private System.Windows.Forms.Button btnComp;
        private System.Windows.Forms.TextBox txtPlvr1;
        private System.Windows.Forms.TextBox txtPlvr2;
        private System.Windows.Forms.Button btnInser2;
        private System.Windows.Forms.Button btnInser1;
    }
}