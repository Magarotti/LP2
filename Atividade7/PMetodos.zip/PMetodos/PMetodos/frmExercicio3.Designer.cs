﻿namespace PMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInv = new System.Windows.Forms.Button();
            this.btnRem2 = new System.Windows.Forms.Button();
            this.txtPlvr2 = new System.Windows.Forms.TextBox();
            this.txtPlvr1 = new System.Windows.Forms.TextBox();
            this.btnRem1 = new System.Windows.Forms.Button();
            this.lblPlvr2 = new System.Windows.Forms.Label();
            this.lblPlvr1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInv
            // 
            this.btnInv.Location = new System.Drawing.Point(355, 208);
            this.btnInv.Name = "btnInv";
            this.btnInv.Size = new System.Drawing.Size(75, 55);
            this.btnInv.TabIndex = 13;
            this.btnInv.Text = "Inverter";
            this.btnInv.UseVisualStyleBackColor = true;
            this.btnInv.Click += new System.EventHandler(this.BtnInv_Click);
            // 
            // btnRem2
            // 
            this.btnRem2.Location = new System.Drawing.Point(203, 208);
            this.btnRem2.Name = "btnRem2";
            this.btnRem2.Size = new System.Drawing.Size(75, 55);
            this.btnRem2.TabIndex = 12;
            this.btnRem2.Text = "Remover 2";
            this.btnRem2.UseVisualStyleBackColor = true;
            this.btnRem2.Click += new System.EventHandler(this.BtnRem2_Click);
            // 
            // txtPlvr2
            // 
            this.txtPlvr2.Location = new System.Drawing.Point(109, 103);
            this.txtPlvr2.Name = "txtPlvr2";
            this.txtPlvr2.Size = new System.Drawing.Size(321, 20);
            this.txtPlvr2.TabIndex = 11;
            // 
            // txtPlvr1
            // 
            this.txtPlvr1.Location = new System.Drawing.Point(109, 30);
            this.txtPlvr1.Name = "txtPlvr1";
            this.txtPlvr1.Size = new System.Drawing.Size(321, 20);
            this.txtPlvr1.TabIndex = 10;
            // 
            // btnRem1
            // 
            this.btnRem1.Location = new System.Drawing.Point(53, 208);
            this.btnRem1.Name = "btnRem1";
            this.btnRem1.Size = new System.Drawing.Size(75, 55);
            this.btnRem1.TabIndex = 9;
            this.btnRem1.Text = "Remover 1";
            this.btnRem1.UseVisualStyleBackColor = true;
            this.btnRem1.Click += new System.EventHandler(this.BtnRem1_Click);
            // 
            // lblPlvr2
            // 
            this.lblPlvr2.AutoSize = true;
            this.lblPlvr2.Location = new System.Drawing.Point(34, 106);
            this.lblPlvr2.Name = "lblPlvr2";
            this.lblPlvr2.Size = new System.Drawing.Size(52, 13);
            this.lblPlvr2.TabIndex = 8;
            this.lblPlvr2.Text = "Palavra 2";
            // 
            // lblPlvr1
            // 
            this.lblPlvr1.AutoSize = true;
            this.lblPlvr1.Location = new System.Drawing.Point(34, 33);
            this.lblPlvr1.Name = "lblPlvr1";
            this.lblPlvr1.Size = new System.Drawing.Size(52, 13);
            this.lblPlvr1.TabIndex = 7;
            this.lblPlvr1.Text = "Palavra 1";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 312);
            this.Controls.Add(this.btnInv);
            this.Controls.Add(this.btnRem2);
            this.Controls.Add(this.txtPlvr2);
            this.Controls.Add(this.txtPlvr1);
            this.Controls.Add(this.btnRem1);
            this.Controls.Add(this.lblPlvr2);
            this.Controls.Add(this.lblPlvr1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInv;
        private System.Windows.Forms.Button btnRem2;
        private System.Windows.Forms.TextBox txtPlvr2;
        private System.Windows.Forms.TextBox txtPlvr1;
        private System.Windows.Forms.Button btnRem1;
        private System.Windows.Forms.Label lblPlvr2;
        private System.Windows.Forms.Label lblPlvr1;
    }
}