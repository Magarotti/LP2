﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnContaN_Click(object sender, EventArgs e)
        {
            int contador = 0;

            foreach (var c in rchtxtFrase.Text)
            {
                if (char.IsNumber(c))
                {
                    contador += 1;
                }
            }


            MessageBox.Show($"n° de numeros: {contador}");
        }

        private void FrmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void BtnContaL_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for (var i = 0; i < rchtxtFrase.Text.Length; i++)
            {
              if (char.IsLetter(rchtxtFrase.Text[1]))
                contador += 1;
            }

            MessageBox.Show($"n° de caracteres: {contador}");
        }

        private void BtnBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contador = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador++;
            }
            MessageBox.Show($"A posição do primeiro espaço em branco é: {posicao}");
        }
    }
}
