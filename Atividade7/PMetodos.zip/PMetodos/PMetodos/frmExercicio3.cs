﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnRem1_Click(object sender, EventArgs e)
        {
            txtPlvr1.Text = txtPlvr1.Text.ToLower();
            txtPlvr2.Text = txtPlvr2.Text.ToLower();

            int posicao = txtPlvr2.Text.IndexOf(txtPlvr1.Text);

            while (posicao >= 0)
            {
                txtPlvr2.Text = txtPlvr2.Text.Substring(0, posicao) + txtPlvr2.Text.Substring(posicao + txtPlvr1.Text.Length,
                txtPlvr2.Text.Length - posicao - txtPlvr1.Text.Length);

                posicao = txtPlvr2.Text.IndexOf(txtPlvr1.Text);
            }
        }

        private void BtnRem2_Click(object sender, EventArgs e)
        {
            txtPlvr2.Text = txtPlvr2.Text.Replace(txtPlvr1.Text, "");
        }

        private void BtnInv_Click(object sender, EventArgs e)
        {
            char[] vetor = txtPlvr1.Text.ToCharArray();
            Array.Reverse(vetor);
            txtPlvr2.Text = "";
            foreach (char c in vetor)
            {
                txtPlvr2.Text += c;
            }
        }
    }
}
