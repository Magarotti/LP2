﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnContaN = new System.Windows.Forms.Button();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnContaL = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnContaN
            // 
            this.btnContaN.Location = new System.Drawing.Point(93, 343);
            this.btnContaN.Name = "btnContaN";
            this.btnContaN.Size = new System.Drawing.Size(100, 46);
            this.btnContaN.TabIndex = 0;
            this.btnContaN.Text = "Contar numeros";
            this.btnContaN.UseVisualStyleBackColor = true;
            this.btnContaN.Click += new System.EventHandler(this.BtnContaN_Click);
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(277, 343);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(100, 46);
            this.btnBranco.TabIndex = 1;
            this.btnBranco.Text = "Primeira posição de branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.BtnBranco_Click);
            // 
            // btnContaL
            // 
            this.btnContaL.Location = new System.Drawing.Point(472, 343);
            this.btnContaL.Name = "btnContaL";
            this.btnContaL.Size = new System.Drawing.Size(105, 46);
            this.btnContaL.TabIndex = 2;
            this.btnContaL.Text = "Contar letras";
            this.btnContaL.UseVisualStyleBackColor = true;
            this.btnContaL.Click += new System.EventHandler(this.BtnContaL_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Escreva";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(153, 24);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(100, 96);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(121, 24);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(409, 230);
            this.rchtxtFrase.TabIndex = 5;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 418);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnContaL);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.btnContaN);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.FrmExercicio4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnContaN;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnContaL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}