﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        double n1, n2, r;

        public Form1()
        {
            InitializeComponent();
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            r = n1 - n2;
            txtRes.Text = Convert.ToString(r);
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair mesmo?","Sair",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            Close();
        }

        private void TxtN2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtN2.Text, out n2))
            {
                MessageBox.Show("Número inválido","Erro",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtN2.Focus();
            }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            r = n1 + n2;
            txtRes.Text = Convert.ToString(r);
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            r = n1 * n2;
            txtRes.Text = Convert.ToString(r);
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (n2 == 0)
            {
                MessageBox.Show("Não pode ser zero","Erro",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtN2.Focus();
            }
            else
            { 
                r = n1 / n2;
                txtRes.Text = Convert.ToString(r);
            }
        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
            txtRes.Clear();
            txtN1.Focus();
        }

        private void TxtN1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtN1.Text, out n1))
            {
                MessageBox.Show("Número inválido","Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtN1.Focus();
            }
        }
    }
}
