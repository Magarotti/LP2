﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void BtnVal_Click(object sender, EventArgs e)
        {
            double SB, DINSS, DIRPF, NF, SF, SL;

            SB = Convert.ToDouble(msktxtSalB.Text);
            NF = Convert.ToDouble(numpdFilho.Value);

            if (SB <= 800.47)
            {
                txtAINSS.Text = "7,65%";
                DINSS = 0.0765 * SB;
            }
            else if (SB <= 1050)
            {
                txtAINSS.Text = "8,65%";
                DINSS = 0.0865 * SB;
            }
            else if (SB <= 1400.77)
            {
                txtAINSS.Text = "9%";
                DINSS = 0.09 * SB;
            }
            else if (SB <= 2801.56)
            {
                txtAINSS.Text = "11%";
                DINSS = 0.11 * SB;
            }
            else
            {
                txtAINSS.Text = "Teto";
                DINSS = 308.17;
            }

            if (SB <= 1257.12)
            {
                txtAIRPF.Text = "Isento";
                DIRPF = 0;
            }
            else if (SB <= 2512.08)
            {
                txtAIRPF.Text = "15%";
                DIRPF = 0.15 *SB;
            }
            else
            {
                txtAIRPF.Text = "27.5%";
                DIRPF = 0.275 * SB;
            }

            if (SB <= 435.52)
            {
                SF = 22.33 * NF;
            }
            else if (SB <= 654.61)
            {
                SF = 15.74 * NF;
            }
            else
            {
                SF = 0;
            }

            SL = SB - DINSS - DIRPF + SF;

            txtDINSS.Text = Convert.ToString(DINSS);
            txtDIRPF.Text = Convert.ToString(DIRPF);
            txtSalFam.Text = Convert.ToString(SF);
            txtSalLiq.Text = Convert.ToString(SL);
        }

        private void MsktxtSalB_Validated(object sender, EventArgs e)
        {

        }

        private void TxtNome_Validating(object sender, CancelEventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Por Favor digite um nome");
                txtNome.Focus();
            }
        }
    }
}
