﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[3,2];
            string aux = "";
            double media1 = 0.0;
            double media2 = 0.0;

            lstbxOutput.Items.Clear();

            for (int i = 0; i < 3; i++)
            {
                
                for (int j = 0; j < 2; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota do {j+1} Filme:", $"{i+1}ª Pessoa: ");

                    if (!Double.TryParse(aux, out notas[i,j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Entrada inválida!");
                        j--;
                    }
                    else
                    {
                        if (j == 0)
                        {
                            media1 += notas[i, j];
                        }
                        else
                        {
                            media2 += notas[i, j];
                        }
                    }

                }

                lstbxOutput.Items.Add("Pessoa: " + (i + 1) + " Nota Filme 1: " + (notas[i, 0]).ToString("N2") + " Nota Filme 2: " + (notas[i, 1]).ToString("N2"));

            }

            lstbxOutput.Items.Add("-----------------------------------");
            lstbxOutput.Items.Add("Média Filme 1 : " + (media1/3).ToString("N2"));
            lstbxOutput.Items.Add("Média Filme 2 : " + (media2/3).ToString("N2"));


        }
    }
}
